import java.awt.event.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

public class BotonResumen extends JLabel {

	BotonResumen(PanelPrincipal panelPrincipal) {
		setIcon(new ImageIcon("Assets\\ResumenPuntuaciones.png"));

		addMouseListener(new MouseAdapter() {
			public void mouseExited(MouseEvent Autores) {
				setIcon(new ImageIcon("Assets\\ResumenPuntuaciones.png"));
			}

			public void mouseClicked(MouseEvent Autores) {
				panelPrincipal.irAutores();
			}

			public void mouseEntered(MouseEvent Autores) {
				setIcon(new ImageIcon("Assets\\ResumenPuntuaciones_cursor.png"));
			}

			public void mousePressed(MouseEvent Autores) {
				setIcon(new ImageIcon("Assets\\ResumenPuntuaciones_click.png"));
			}

		});
	}
}
