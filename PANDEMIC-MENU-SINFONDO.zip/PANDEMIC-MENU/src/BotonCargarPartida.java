import java.awt.event.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

public class BotonCargarPartida extends JLabel {

	BotonCargarPartida(PanelPrincipal panelPrincipal) {
		setIcon(new ImageIcon("Assets\\CargarPartida.png"));

		addMouseListener(new MouseAdapter() {
			public void mouseExited(MouseEvent CargarPartida) {
				setIcon(new ImageIcon("Assets\\CargarPartida.png"));
			}

			public void mouseClicked(MouseEvent CargarPartida) {
				panelPrincipal.irCargarPartida();
			}

			public void mouseEntered(MouseEvent CargarPartida) {
				setIcon(new ImageIcon("Assets\\CargarPartida_cursor.png"));
			}

			public void mousePressed(MouseEvent CargarPartida) {
				setIcon(new ImageIcon("Assets\\CargarPartida_click.png"));
			}

		});
	}
}
