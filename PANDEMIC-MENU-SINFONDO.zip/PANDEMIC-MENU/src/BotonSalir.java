import java.awt.event.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

public class BotonSalir extends JLabel {

	BotonSalir(PanelPrincipal panelPrincipal) {
		setIcon(new ImageIcon("Assets\\salir.png"));

		addMouseListener(new MouseAdapter() {
			public void mouseExited(MouseEvent Autores) {
				setIcon(new ImageIcon("Assets\\salir.png"));
			}

			public void mouseClicked(MouseEvent Autores) {
				panelPrincipal.irSalir();
			}

			public void mouseEntered(MouseEvent Autores) {
				setIcon(new ImageIcon("Assets\\salir.png"));
			}

			public void mousePressed(MouseEvent Autores) {
				setIcon(new ImageIcon("Assets\\salir.png"));
			}

		});
	}
}
