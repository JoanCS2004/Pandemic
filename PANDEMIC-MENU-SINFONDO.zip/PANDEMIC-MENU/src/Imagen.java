import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Imagen extends JPanel {

	private static final long serialVersionUID = 1L;

	public Imagen() {
		this.setSize(600, 400);
	}

	public void paintComponent (Graphics g) {
		 Dimension tamanio = getSize();
		 ImageIcon imagenFondo = new ImageIcon (getClass().getResource("PANDEMIC-BACKGROUND.png"));
		 g.drawImage(imagenFondo.getImage(), 0, 0, tamanio.width, tamanio.height, null); setOpaque (false);
		 super.paintComponent(g);
}
}
