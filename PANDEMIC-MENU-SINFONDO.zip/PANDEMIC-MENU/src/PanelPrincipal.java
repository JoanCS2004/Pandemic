import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class PanelPrincipal extends JPanel implements ActionListener {

	BotonNuevaPartida boton1;
	BotonCargarPartida boton2;
	BotonInformacion boton3;
	BotonResumen boton4;
	BotonAutores boton5;
	BotonVersion boton6;
	BotonSalir boton7;
	JTextField areaDeTexto;

	private Image imagenFondo;
	
	PanelPrincipal() {

		setLayout(new FlowLayout());

		boton1 = new BotonNuevaPartida(this);
		boton2 = new BotonCargarPartida(this);
		boton3 = new BotonInformacion(this);
		boton4 = new BotonResumen(this);
		boton5 = new BotonAutores(this);
		boton6 = new BotonVersion(this);
		boton7 = new BotonSalir(this);

		areaDeTexto = new JTextField(20);

		// boton1.addActionListener(this);
		//boton2.addActionListener(this);
		//boton3.addActionListener(this);
		//boton4.addActionListener(this);
		//boton5.addActionListener(this);
		//boton6.addActionListener(this);
		//boton7.addActionListener(this);

		add(boton1);
		add(boton2);
		add(boton3);
		add(boton4);
		add(boton5);
		add(boton6);
		add(boton7);

		//imagenFondo = null;
	   //ImageIcon icon = new ImageIcon(("Assets\\PANDEMIC-BACKGROUND.png"));
	}

	@Override
	protected void paintComponent(Graphics g) {
	    super.paintComponent(g);
	    if (imagenFondo != null) {
	        g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), this);
	    }
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == boton1) {
			System.out.println("Aqui començara una nova partida");
			JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
			marco.remove(this);
			marco.add(new PanelNuevaPartida());
			marco.setVisible(true);
		}

		else if (e.getSource() == boton2) {
			System.out.println("Aqui començara una nova partida");
			JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
			marco.remove(this);
			marco.add(new PanelCargarPartida());
			marco.setVisible(true);
		}

		else if (e.getSource() == boton3) {
			JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
			marco.remove(this);
			marco.add(new PanelInformacion());
			marco.setVisible(true);
		}

		else if (e.getSource() == boton4) {
			System.out.println("Resum de les puntuacions");
		}

		else if (e.getSource() == boton5) {
			JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
			marco.remove(this);
			marco.add(new PanelAutores());
			marco.setVisible(true);
		}

		else if (e.getSource() == boton6) {
			JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
			marco.remove(this);
			marco.add(new PanelVersion());
			marco.setVisible(true);
		}
		else if (e.getSource() == boton7) {
			System.exit(0);
		}
	}

	public void irNuevaPartida() {
		JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
		marco.remove(this);
		marco.add(new PanelNuevaPartida());
		marco.setVisible(true);
	}
	public void irCargarPartida() {
		JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
		marco.remove(this);
		marco.add(new PanelCargarPartida());
		marco.setVisible(true);
	}
	public void irInformacion() {
		JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
		marco.remove(this);
		marco.add(new PanelInformacion());
		marco.setVisible(true);
	}
	public void irResumenPuntuaciones() {
		JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
		marco.remove(this);
		marco.add(new PanelResumenPuntuaciones());
		marco.setVisible(true);
	}
	public void irAutores() {
		JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
		marco.remove(this);
		marco.add(new PanelAutores());
		marco.setVisible(true);
	}
	public void irVersion() {
		JFrame marco = (JFrame) SwingUtilities.getWindowAncestor(this);
		marco.remove(this);
		marco.add(new PanelVersion());
		marco.setVisible(true);
	}
	public void irSalir() {
		System.exit(0);
	}
}